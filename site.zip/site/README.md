# ORTOLEVE - SITE FUNCIONAL

## Pagina de Empresa Ortoleve  

Funções:  

--> Tem que ser responsivo  
--> Horário e dias de atendimento  
--> Informações sobre a Ortoleve  
--> Informações sobre as especialidades  
--> Colocar os dentitas com fotos  
--> Página de Fale conosco por e-mail e número de whatsapp  
--> Página de planos conveniados  
--> Fotos do local  
--> Localização com mapa    
--> Depoimentos  
--> Área do Cliente com Login  

Menu:  

--> Ortoleve  
- Quem somos
- Especialidades  
- Profissionais  
- Fotos do Local  
- Depoimentos  
- Planos  

--> Contato com Mapa  
--> Área do Cliente (Número Carteira, Senha, Nome, Perfil, Tabela fornecida).

> Banco de dados MySQL na área do cliente.

Slide:  

--> Horário de Funcionamento com a frase "Horário de Funcionamento: 08h00 as 18h00"  
--> Foto do local com a frase "Conforto para melhor atender"  
--> Foto dos profissionais juntos com a frase "Profissionais qualificados em diversas áreas"  

> Site ainda em construção.