<footer id="footer" class="footer">
    
    <div class="footer-bottom">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-md-6 sm-text-center">
            <p class="font-13 text-black-777 m-0">Ortoleve | Clínica de Odontologia Especializada</p>
            <p class="font-13 text-black-777 m-0">Copyright &copy;<?php echo date("Y"); ?>. Todos os direitos reservados.</p>
          </div>
          <div class="col-md-6 text-right flip sm-text-center">
            <div class="widget no-border m-0">
              <ul class="styled-icons icon-dark icon-circled icon-sm">
                <li><a href="https://www.facebook.com/ortoleve.centrodeortodontia"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.instagram.com/ortolevecentrodeortodontia"><i class="fa fa-instagram"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>